//
//  AmQNative.h
//  AmQNative
//
//  Created by admin on 2019/1/23.
//  Copyright © 2019 cyou. All rights reserved.
//

#import "Common.h"

#ifndef AmQNative_h
#define AmQNative_h


_DLLExport FLOAT AmQ_UnityNativePlugin();
_DLLExport VOID AmQ_DestroyNative();
_DLLExport INT CreateFileBuffer(STRING szFileName);
_DLLExport INT CreateBufferFromFile(STRING szFileName, UINT offset, UINT dataSize);
_DLLExport VOID BufferGetByte(INT bufferID, UINT offset, BYTE& data);
_DLLExport VOID BufferGetDouble(INT bufferID, UINT offset, DOUBLE& data);
_DLLExport VOID BufferGetFloat(INT bufferID, UINT offset, FLOAT& data);
_DLLExport VOID BufferGetInt(INT bufferID, UINT offset, INT& data);
_DLLExport VOID BufferGetLong(INT bufferID, UINT offset, INT64& data);
_DLLExport VOID BufferGetSbyte(INT bufferID, UINT offset, SBYTE& data);
_DLLExport VOID BufferGetShort(INT bufferID, UINT offset, SHORT& data);
_DLLExport VOID BufferGetUShort(INT bufferID, UINT offset, USHORT& data);
_DLLExport VOID BufferGetUInt(INT bufferID, UINT offset, UINT& data);
_DLLExport VOID BufferGetULong(INT bufferID, UINT offset, UINT64& data);
_DLLExport VOID BufferGetData(INT bufferID, UINT offset, UINT dataSize,CHAR* data);

#endif /* AmQNative_h */
